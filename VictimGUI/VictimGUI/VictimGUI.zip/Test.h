#pragma once

void testVictim();

void testDynamicVector();

void testRepository();

void testService();

void testAssistantRepository();

void testFileRepository();